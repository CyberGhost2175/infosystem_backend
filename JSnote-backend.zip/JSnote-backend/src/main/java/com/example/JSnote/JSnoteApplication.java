package com.example.JSnote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JSnoteApplication {

	public static void main(String[] args) {
		SpringApplication.run(JSnoteApplication.class, args);
	}

}
