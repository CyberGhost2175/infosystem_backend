package com.example.JSnote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JSnoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
